package com.jspiders.hospital_app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospital_app.entity.Branch;
import com.jspiders.hospital_app.entity.Hospital;
import com.jspiders.hospital_app.service.HospitalService;
import com.jspiders.hospital_app.util.ResponseStructure;

import jakarta.validation.Valid;

@RestController
public class HospitalController {

	@Autowired
	private HospitalService hospitalService;

	@PostMapping("/saveHospital") 	//to test select POST in Postman --and add url -- http://localhost:8080/saveHospital and write json
	public ResponseEntity<ResponseStructure<Hospital>> saveHospital(@RequestBody @Valid Hospital hospital) {
		return hospitalService.saveHospital(hospital);
	}

	@GetMapping("/getHospital")  // to test select GET in Postman --and add url Eg: --  http://localhost:8080/getHospital?h_id=1011
	public ResponseEntity<ResponseStructure<Hospital>> findHospitalById(@RequestParam int id) {
		return hospitalService.getHospitalById(id);
	}

	@PutMapping("/updateHospital")  //to test select PUT in Postman --add url Eg: -- http://localhost:8080/updateHospital?id=1015  and write json 
	public ResponseEntity<ResponseStructure<Hospital>> updateHospital(@RequestParam int id,
			@RequestBody Hospital hospital) {
		return hospitalService.updateHospitalById(id, hospital);
	}

	@DeleteMapping("/deleteHospital")  // to test select DELETE in Postman --and add url Eg: -- http://localhost:8080/deleteHospital?id=1013
	public ResponseEntity<ResponseStructure<Hospital>> deleteHospital(@RequestParam int id) {
		return hospitalService.deleteHospitalById(id);
	}

	@GetMapping("/getbranches")
	public ResponseEntity<ResponseStructure<List<Branch>>> getBranch(@RequestParam int id) {
		return hospitalService.getBrachesHospitalById(id);
	}
	
}
