package com.jspiders.hospital_app.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String address_state;
	private String address_district;
	private int address_pincode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress_state() {
		return address_state;
	}
	public void setAddress_state(String address_state) {
		this.address_state = address_state;
	}
	public String getAddress_district() {
		return address_district;
	}
	public void setAddress_district(String address_district) {
		this.address_district = address_district;
	}
	public int getAddress_pincode() {
		return address_pincode;
	}
	public void setAddress_pincode(int address_pincode) {
		this.address_pincode = address_pincode;
	}
	
	
}
