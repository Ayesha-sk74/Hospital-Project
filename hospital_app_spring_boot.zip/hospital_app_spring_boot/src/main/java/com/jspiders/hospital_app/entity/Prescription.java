package com.jspiders.hospital_app.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Prescription {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prescrpiton_id;
	
	private String type;
	private String status;

	@OneToMany
	private List<MedicalItems> items;

	public int getPrescrpiton_id() {
		return prescrpiton_id;
	}

	public void setPrescrpiton_id(int prescrpiton_id) {
		this.prescrpiton_id = prescrpiton_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<MedicalItems> getItems() {
		return items;
	}

	public void setItems(List<MedicalItems> items) {
		this.items = items;
	}
	
	
	
	
}
