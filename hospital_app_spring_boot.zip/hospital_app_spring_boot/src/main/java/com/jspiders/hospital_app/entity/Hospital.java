package com.jspiders.hospital_app.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Hospital {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hospital_id;
	private String hostpital_name;
	private String main_address;

	@Min(6000000)
	@Max(999999999)
//	@Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "Invalid phone number")
	private long hospital_phone;

	
	private String hostimal_email;

	@UpdateTimestamp
	private LocalDateTime creationTime;

	@OneToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	private List<Branch> branchs;

	public int getHospital_id() {
		return hospital_id;
	}

	public void setHospital_id(int hospital_id) {
		this.hospital_id = hospital_id;
	}

	public String getHostpital_name() {
		return hostpital_name;
	}

	public void setHostpital_name(String hostpital_name) {
		this.hostpital_name = hostpital_name;
	}

	public String getMain_address() {
		return main_address;
	}

	public void setMain_address(String main_address) {
		this.main_address = main_address;
	}

	public long getHospital_phone() {
		return hospital_phone;
	}

	public void setHospital_phone(long hospital_phone) {
		this.hospital_phone = hospital_phone;
	}

	public String getHostimal_email() {
		return hostimal_email;
	}

	public void setHostimal_email(String hostimal_email) {
		this.hostimal_email = hostimal_email;
	}

	public LocalDateTime getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(LocalDateTime creationTime) {
		this.creationTime = creationTime;
	}

	public List<Branch> getBranchs() {
		return branchs;
	}

	public void setBranchs(List<Branch> branchs) {
		this.branchs = branchs;
	}
	
	

}
