package com.jspiders.hospital_app.entity;

import java.util.List;


import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int patient_id;
	private String patientName;
	private int patient_age;
	private long patient_phone;
	private String patient_email;

	@OneToMany
	private List<AppointmentRecord> record;

	@ManyToMany(mappedBy = "patient",fetch = FetchType.LAZY)
	private List<Branch> branches;

	public int getPatient_id() {
		return patient_id;
	}

	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getPatient_age() {
		return patient_age;
	}

	public void setPatient_age(int patient_age) {
		this.patient_age = patient_age;
	}

	public long getPatient_phone() {
		return patient_phone;
	}

	public void setPatient_phone(long patient_phone) {
		this.patient_phone = patient_phone;
	}

	public String getPatient_email() {
		return patient_email;
	}

	public void setPatient_email(String patient_email) {
		this.patient_email = patient_email;
	}

	public List<AppointmentRecord> getRecord() {
		return record;
	}

	public void setRecord(List<AppointmentRecord> record) {
		this.record = record;
	}

	public List<Branch> getBranches() {
		return branches;
	}

	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}
	
	
}
